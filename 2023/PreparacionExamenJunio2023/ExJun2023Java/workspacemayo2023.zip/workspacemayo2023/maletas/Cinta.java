package maletas;
public class Cinta {

	private int maletasPrimera, maletasTurista, primeraEsperando;
	
	public Cinta() {
	
	}
	
	public void poner(boolean primeraClase) throws InterruptedException {
	
	}
	

	public void qRetirarPrimera(int pasajeroId) throws InterruptedException {
	
	}
	
	public void qRetirarTurista(int pasajeroId) throws InterruptedException {
	
	}
	
	public void fRetirarPrimera(int pasajeroId) throws InterruptedException {
	
	}
	public void fRetirarTurista(int pasajeroId) throws InterruptedException {
		
	}

}

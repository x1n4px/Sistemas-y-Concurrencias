#include <stdlib.h>
#include <stdio.h>
#include "gestion_tremor.h"


void iniciar(T_Lista *ptr_lista_nuevos, T_Lista *ptr_lista_procesados);


void mostrar_nuevos2antiguos(T_Lista lista);

void registrar(T_Lista *ptr_lista_nuevos, const time_t *fecha, unsigned duracion, unsigned *ok);


void procesar(T_Lista *ptr_lista_nuevos, const time_t *fecha, T_Lista *ptr_lista_procesados);

void destruir(T_Lista *ptr_lista_nuevos, T_Lista *ptr_lista_procesados);
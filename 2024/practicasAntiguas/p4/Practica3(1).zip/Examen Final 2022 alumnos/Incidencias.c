/*
 ============================================================================
 Name        : Main2022.c
 Authors     : JB,
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */

#include "Incidencias.h"

// Contador del número de incidencias, se inicializa a 0.
int contId;

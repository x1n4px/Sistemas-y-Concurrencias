package esqueleto;


public class Table {
	

	public Table(int numProducers) {
	
	}

	
	public void put(int id, int datum) {
		
	}

	public int get(){
		return 0;
	}

}

package viajebarco;

import java.util.concurrent.Semaphore;

public class Barco {
	
	

	public void viaje(int id) throws InterruptedException {
		
		
	

		
		
			
	}

	public void empiezaViaje() throws InterruptedException {
		
	}
	public void finViaje() throws InterruptedException  {
		
	}
}

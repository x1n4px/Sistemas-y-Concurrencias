package viajebarco;

import java.util.*;
public class Capitan extends Thread{

	private Barco barco;
	public Capitan(Barco tren) {
		this.barco = tren;
	}
	private Random r = new Random();
	public void run() {
		while (true) {
			try {
				barco.empiezaViaje();
				Thread.sleep(r.nextInt(1000));
				barco.finViaje();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}

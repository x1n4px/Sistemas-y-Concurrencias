package viajebarco;

public class Principal {

	public static void main(String[] args) {
		Barco tren = new Barco();
		Capitan m = new Capitan(tren);
		Viajero[] pas = new Viajero[20];
		for (int i=0; i<pas.length; i++)
			pas[i] = new Viajero(tren,i);
		m.start();
		for (int i=0; i<pas.length; i++)
			pas[i].start();
	}
}

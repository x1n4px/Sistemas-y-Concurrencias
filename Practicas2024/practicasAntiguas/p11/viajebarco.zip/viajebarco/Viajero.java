package viajebarco;

public class Viajero extends Thread{

	private int id;
	private Barco barco;
	
	public Viajero(Barco b, int id) {
		this.barco = b;
		this.id = id;
	}
	
	
	public void run() {
		while (true) {
			try {
				Thread.sleep(2000);
				barco.viaje(id);
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

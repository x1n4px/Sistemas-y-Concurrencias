/*
 * arbolbb.c
 *
 *  Created on: 15 mar. 2021
 *      Author: Laura
 */
#include <stdio.h>
#include <stdlib.h>
#include "arbolbb.h"


// Inicializa la estructura a NULL.
void Crear(T_Arbol* arbol_ptr){

}

// Destruye la estructura utilizada.
void Destruir(T_Arbol *arbol_ptr){

}

// Inserta num en el arbol
void Insertar(T_Arbol *arbol_ptr,unsigned num)
{
	
	
	
}
// Muestra el contenido del árbol en InOrden
void Mostrar(T_Arbol arbol){

}


// Guarda en disco el contenido del arbol - recorrido InOrden
void Salvar(T_Arbol arbol, FILE *fichero){

	
}


void decrypt(unsigned * v, unsigned * k){
;
}
int main(int argc, char const *argv[])
{
    unsigned k[4]={128, 129, 130, 131}; 

    
    return 0;
}
